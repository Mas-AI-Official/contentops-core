"""
Prompt templates for content generation.
"""
